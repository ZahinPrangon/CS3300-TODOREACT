const todosData = [
    {
        id: 1,
        text: "Wake up at 6:30am",
        completed: false,
    },
    {
        id: 2,
        text: "Make breakfast at 8am",
        completed: false,
    },
    {
        id: 3,
        text: "Go to work at 11am",
        completed: false,
    },
    {
        id: 4,
        text: "Work on your personal project",
        completed: false,
    },
    {
        id: 5,
        text: "Sleep at 11pm",
        completed: false,
    }
]

export default todosData